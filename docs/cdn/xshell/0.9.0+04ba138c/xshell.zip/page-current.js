import pageRegistry from "./page-registry.js";
export default pageRegistry.getPage("PAGE_ID");
